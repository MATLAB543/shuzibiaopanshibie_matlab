function varargout = GUI(varargin)
% GUI MATLAB code for GUI.fig
%      GUI, by itself, creates a new GUI or raises the existing
%      singleton*.
%
%      H = GUI returns the handle to a new GUI or the handle to
%      the existing singleton*.
%
%      GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GUI.M with the given input arguments.
%
%      GUI('Property','Value',...) creates a new GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before GUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to GUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help GUI

% Last Modified by GUIDE v2.5 22-Feb-2021 13:32:46

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @GUI_OpeningFcn, ...
                   'gui_OutputFcn',  @GUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before GUI is made visible.
function GUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to GUI (see VARARGIN)

% Choose default command line output for GUI
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes GUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = GUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
[filename,pathname] = uigetfile({'*.jpg;*.bmp;*.tif;*.png;*.gif','All Image Files'},'��ѡ��һ��ͼƬ');
if filename == 0%���û��ѡ��ֱ�ӷ��ؼ���
    return;
end
file = strcat(pathname,filename);%ȡ��ͼ���ļ�ȫ�� 
I0 = imread(file);
axes(handles.axes1);imshow(I0);title('������ͼƬ');
save I0
set(handles.text2,'string','��ͼ����ϣ�')
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
load I0
scale = 1000/length(I0);
Irsz = imresize(I0,scale);
clear I0;
  
%%%%%%������%%%%%%

        if length(size(Irsz))==3
            Ig=rgb2gray(Irsz);
        else
            Ig=Irsz;
        end
        clear Irsz;
        If = imfill(Ig);
        
        Ib = im2bw(If,graythresh(If));
        axes(handles.axes2)
        imshow(Ib)
        title('��ֵͼ��')
        clear If;
        save Ib
        set(handles.text2,'string','��ֵͼ������ϣ�')
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
load Ib
 clear If;
        % figure;imshow(Ib);%-----------------------------------

        SE = strel('square',25);
        
        Ied = imerode(Ib,SE);
        axes(handles.axes3)
        imshow(Ied)
        title('���������ֵ��λ')
        save Ied
        set(handles.text2,'string','��λ������ϣ�')
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
load Ied
clear Ib;
        L = bwlabel(Ied);
        
        axes(handles.axes4)
        imshow(L)
        title('��ͬ����')
        save L
        set(handles.text2,'string','��ͨ��������ϣ�')
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
load L
 
        stats = regionprops(L,'Area');
         
        
        idx = find([stats.Area] == max([stats.Area]));
        [r,c] = find( L==idx );
        clear L;
        r1=min(r);r2=max(r);c1=min(c);c2=max(c);
        rect = [c1,r1,c2-c1,r2-r1];
        Ic = imcrop(Ig,rect);clear Ig;
       axes(handles.axes5);
        imshow(Ic);
        title('������������')
        save Ic
        set(handles.text2,'string','��������ָ���ϣ�')
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
load Ic

        level = graythresh(Ic)/2;   %����֮���ͼƬ��ֵ��
        Ib=im2bw(Ic,level);clear Ic;
        mp = mean(mean(Ib(1,:))+mean(Ib(end,:))...
             +mean(Ib(:,1))+mean(Ib(:,end)));
        if mp>0.5
            Ib = ~Ib;
        end
        axes(handles.axes6);imshow(Ib);
         title('��λͼ��ֵ������')%-------------------
         save Ib
         set(handles.text2,'string','ֻ����Ԥ�������֣��ָ��ʶ�𲿷���Ҫ���Q2869939756��')

% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
load Ib
  [m,n] = size(Ib);
        SE = strel('square',round(m/50)); %����ȥ�룬ͼƬ�����㣨�ȸ�ʴ�����ͣ���ȥ������
        Iop = imopen(Ib,SE);
         axes(handles.axes7);imshow(Iop);
          title('������')
          save Iop
          set(handles.text2,'string','�����㴦����ϣ�')
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton8.
function pushbutton8_Callback(hObject, eventdata, handles)
load Iop
 SE = strel('square',round(m/25));    
        Icl = imclose(Iop,SE);clear Iop; %�����㣬ϣ����������ֵĸ�LED��������һ��
            axes(handles.axes8);imshow(Icl);
            title('������')%-------------------
            save Icl
            set(handles.text2,'string','�����㴦����ϣ�')
% hObject    handle to pushbutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton9.
function pushbutton9_Callback(hObject, eventdata, handles)
load Icl
 Ith = bwmorph(Icl,'thin',inf);%ͼƬϸ���������ֱ�Ϊ��ϸ�����
         axes(handles.axes9); imshow(Ith);
          title('ϸ��')%----------------- 
          save Ith
          set(handles.text2,'string','ϸ��������ϣ�')
% hObject    handle to pushbutton9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton10.
function pushbutton10_Callback(hObject, eventdata, handles)
load Ith
 sRI = sum(Ith');    %��һ��ȥ��
        upidx = find(sRI>0, 1, 'first' );
        dnidx = find(sRI>0, 1, 'last');
        pse = round((dnidx-upidx)/40);
        SE = strel('square',pse);
        Ioc = imopen(Icl,SE);
        Ith = bwmorph(Ioc,'thin',inf);clear Iop;
       
        %%%%%%%%%%%%%%%%%%%%%%%%%���ַ��Ĵ���ʶ��%%%%%%%%%%%%%%%%%%%%%%%%
        %%%cut(��Ϊ�����ǵ��ŵ�)
        %%����
        sRI = sum(Ith');   
        upidx = find(sRI>0, 1, 'first' );
        dnidx = find(sRI>0, 1, 'last');
        udidx = upidx:dnidx;
        ud = length(udidx);
        thrlen = ud/2; %�ж�LED���Ƿ�����ĳ�����ֵ
        Ith = Ith(udidx,:);
        axes(handles.axes10); imshow(Ith);
         title('�����и�')%-----------------
         save Ith
         save thrlen
         set(handles.text2,'string','����λ��ϣ�')
% hObject    handle to pushbutton10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton11.
function pushbutton11_Callback(hObject, eventdata, handles)
msgbox('�ָ��ʶ�𲿷ֻ�û��������Q2869939756')      
% hObject    handle to pushbutton11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton12.
function pushbutton12_Callback(hObject, eventdata, handles)

     set(handles.text2,'string','�ָ��ʶ�𲿷ֻ�û��������Q2869939756��')

% hObject    handle to pushbutton12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
